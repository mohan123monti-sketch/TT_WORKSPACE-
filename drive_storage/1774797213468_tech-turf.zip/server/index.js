const express = require('express');
const cors    = require('cors');
const path    = require('path');
const fs      = require('fs');
const { createServer: createViteServer } = require('vite');
require('dotenv').config();

async function startServer() {
  const app  = express();
  const PORT = process.env.PORT || 3000;
  const db   = require('./db');

  // Ensure uploads directory exists
  const uploadsDir = path.join(__dirname, '../uploads');
  if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

  // CORS
  app.use(cors({
    origin: process.env.APP_URL || `http://localhost:${PORT}`,
    credentials: true
  }));
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Seed database
  const seed = require('./seed');
  await seed();

  // API Routes
  app.use('/api/auth',          require('./routes/auth.routes'));
  app.use('/api/users',         require('./routes/users.routes'));
  app.use('/api/projects',      require('./routes/projects.routes'));
  app.use('/api/tasks',         require('./routes/tasks.routes'));
  app.use('/api/submissions',   require('./routes/submissions.routes'));
  app.use('/api/nexus',         require('./routes/nexus.routes'));
  app.use('/api/clients',       require('./routes/clients.routes'));
  app.use('/api/announcements', require('./routes/announcements.routes'));
  app.use('/api/notifications', require('./routes/notifications.routes'));

  // Serve uploads
  app.use('/uploads', express.static(uploadsDir));

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // ── DEADLINE PULSE ──────────────────────
  function runDeadlineAlerts() {
    try {
      const dueSoon = db.prepare(`
        SELECT t.*, p.team_leader_id FROM tasks t
        JOIN projects p ON p.id = t.project_id
        WHERE t.status NOT IN ('approved','rejected')
          AND t.deadline IS NOT NULL
          AND date(t.deadline) = date('now','+1 day')
      `).all();
      dueSoon.forEach(t => {
        db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
          .run(t.assigned_to, `⏰ Task "${t.title}" is due TOMORROW. Submit now!`, 'warning');
      });

      const overdue = db.prepare(`
        SELECT t.*, p.team_leader_id FROM tasks t
        JOIN projects p ON p.id = t.project_id
        WHERE t.status NOT IN ('approved','rejected')
          AND t.deadline IS NOT NULL
          AND date(t.deadline) < date('now')
      `).all();
      overdue.forEach(t => {
        db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
          .run(t.assigned_to, `🔴 OVERDUE: "${t.title}" — submit immediately!`, 'danger');
        if (t.team_leader_id) {
          db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
            .run(t.team_leader_id, `🔴 Team member has overdue task: "${t.title}"`, 'danger');
        }
      });
    } catch(e) { console.error('[Deadline Pulse]', e.message); }
  }
  runDeadlineAlerts();
  setInterval(runDeadlineAlerts, 60 * 60 * 1000);

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Tech Turf Server running at http://localhost:${PORT}`);
  });
}

startServer();
