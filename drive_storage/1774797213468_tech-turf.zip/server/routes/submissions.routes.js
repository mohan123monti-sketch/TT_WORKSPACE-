const router  = require('express').Router();
const db      = require('../db');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { verifyToken, checkRole } = require('../auth');

// Multer setup
const uploadsDir = path.join(__dirname, '../../uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename:    (req, file, cb) => {
    const ext  = path.extname(file.originalname);
    const base = path.basename(file.originalname, ext).replace(/[^a-z0-9]/gi, '_').toLowerCase();
    cb(null, `${Date.now()}_u${req.user.id}_${base}${ext}`);
  }
});
const allowedExts = ['.jpg','.jpeg','.png','.gif','.pdf','.mp4','.mov','.docx','.doc','.zip','.rar'];
const fileFilter  = (req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase();
  allowedExts.includes(ext) ? cb(null,true) : cb(new Error(`Type ${ext} not allowed`));
};
const upload = multer({ storage, fileFilter, limits: { fileSize: 50*1024*1024 } });

// Badge assignment helper
async function checkAndAssignBadges(userId) {
  try {
    const recent = db.prepare("SELECT leader_status FROM submissions WHERE submitted_by=? ORDER BY submitted_at DESC LIMIT 5").all(userId);
    if (recent.length === 5 && recent.every(s => s.leader_status==='approved')) {
      const updated = db.prepare("UPDATE users SET badge=? WHERE id=? AND (badge IS NULL OR badge!='Top Scorer')").run('Consistent Approver',userId);
      if (updated.changes) db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)").run(userId,'🏅 You earned the "Consistent Approver" badge!','success');
    }
    const noRev = db.prepare("SELECT COUNT(*) as cnt FROM submissions WHERE submitted_by=? AND version=1 AND leader_status='approved'").get(userId);
    if (noRev.cnt >= 3) db.prepare("UPDATE users SET badge=? WHERE id=? AND badge IS NULL").run('Zero Revisions',userId);

    const top = db.prepare("SELECT submitted_by,AVG(nexus_score) as avg FROM submissions WHERE nexus_score IS NOT NULL AND submitted_at>=date('now','start of month') GROUP BY submitted_by ORDER BY avg DESC LIMIT 1").get();
    if (top && top.submitted_by===userId) {
      db.prepare("UPDATE users SET badge='Top Scorer' WHERE id=?").run(userId);
      db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)").run(userId,'🏆 You are the Top Scorer this month!','success');
    }
  } catch(e) { console.error('Badge error:', e.message); }
}

// POST /api/submissions
router.post('/', verifyToken, upload.single('file'), (req, res) => {
  const { task_id, content_text } = req.body;
  if (!task_id) return res.status(400).json({ message: 'task_id required' });
  const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(task_id);
  if (!task) return res.status(404).json({ message: 'Task not found' });

  const file_path = req.file ? `/uploads/${req.file.filename}` : null;
  if (!content_text && !file_path) return res.status(400).json({ message: 'Provide text content or a file' });

  const version = (db.prepare("SELECT MAX(version) as v FROM submissions WHERE task_id=? AND submitted_by=?").get(task_id, req.user.id)?.v || 0) + 1;
  const result = db.prepare(`
    INSERT INTO submissions(task_id,submitted_by,file_path,content_text,version)
    VALUES(?,?,?,?,?)
  `).run(task_id, req.user.id, file_path, content_text||null, version);

  db.prepare("UPDATE tasks SET status='submitted' WHERE id=?").run(task_id);
  db.prepare("INSERT INTO performance_log(user_id,action,task_id) VALUES(?,?,?)").run(req.user.id,'Submitted work',task_id);

  const project = db.prepare('SELECT team_leader_id FROM projects WHERE id=?').get(task.project_id);
  if (project?.team_leader_id) {
    db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
      .run(project.team_leader_id, `📤 New submission for task "${task.title}" — review required`, 'info');
  }

  res.json({ message: 'Submitted successfully', id: result.lastInsertRowid, version });
});

// GET /api/submissions
router.get('/', verifyToken, (req, res) => {
  const { task_id } = req.query;
  let query = `
    SELECT s.*, t.title as task_title, u.name as submitter_name, u.role as submitter_role,
      p.title as project_title
    FROM submissions s
    JOIN tasks t ON t.id=s.task_id
    JOIN users u ON u.id=s.submitted_by
    JOIN projects p ON p.id=t.project_id
    WHERE 1=1
  `;
  const params = [];
  if (!['admin','team_leader'].includes(req.user.role)) {
    query += ' AND s.submitted_by=?'; params.push(req.user.id);
  }
  if (task_id) { query += ' AND s.task_id=?'; params.push(task_id); }
  query += ' ORDER BY s.submitted_at DESC';
  res.json(db.prepare(query).all(...params));
});

// GET /api/submissions/:id
router.get('/:id', verifyToken, (req, res) => {
  const s = db.prepare(`
    SELECT s.*, t.title as task_title, u.name as submitter_name
    FROM submissions s JOIN tasks t ON t.id=s.task_id JOIN users u ON u.id=s.submitted_by
    WHERE s.id=?
  `).get(req.params.id);
  if (!s) return res.status(404).json({ message: 'Not found' });
  if (s.nexus_feedback && typeof s.nexus_feedback === 'string') {
    try { s.nexus_feedback = JSON.parse(s.nexus_feedback); } catch(_) {}
  }
  res.json(s);
});

// PUT /api/submissions/:id/leader-review
router.put('/:id/leader-review', verifyToken, checkRole('admin','team_leader'), async (req, res) => {
  const { status, note } = req.body;
  const sub = db.prepare('SELECT * FROM submissions WHERE id=?').get(req.params.id);
  if (!sub) return res.status(404).json({ message: 'Not found' });

  db.prepare("UPDATE submissions SET leader_status=? WHERE id=?").run(status, sub.id);

  const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(sub.task_id);
  const newTaskStatus = status==='approved' ? 'approved' : status==='rework' ? 'rework' : 'rejected';
  db.prepare("UPDATE tasks SET status=? WHERE id=?").run(newTaskStatus, sub.task_id);

  if (status === 'approved') {
    db.prepare("UPDATE users SET points=points+10 WHERE id=?").run(sub.submitted_by);
    db.prepare("INSERT INTO performance_log(user_id,action,score,task_id) VALUES(?,?,?,?)").run(sub.submitted_by,'Task Approved',10,sub.task_id);
    db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
      .run(sub.submitted_by, `✅ Your submission for "${task?.title}" was APPROVED! +10 points`, 'success');
    await checkAndAssignBadges(sub.submitted_by);
  } else if (status === 'rejected') {
    db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
      .run(sub.submitted_by, `❌ Your submission for "${task?.title}" was rejected. ${note||''}`, 'danger');
  } else {
    db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
      .run(sub.submitted_by, `🔄 Your submission for "${task?.title}" needs rework. ${note||''}`, 'warning');
  }
  res.json({ message: `Submission ${status}` });
});

// PUT /api/submissions/:id/admin-override
router.put('/:id/admin-override', verifyToken, checkRole('admin'), (req, res) => {
  const { status, note } = req.body;
  db.prepare("UPDATE submissions SET leader_status=?, admin_override=? WHERE id=?").run(status, note||'Admin override', req.params.id);
  res.json({ message: 'Override applied' });
});

module.exports = router;
