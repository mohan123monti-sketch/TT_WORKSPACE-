const router = require('express').Router();
const db     = require('../db');
const { verifyToken, checkRole, hashPassword } = require('../auth');

// GET /api/users
router.get('/', verifyToken, (req, res) => {
  const { role, search } = req.query;
  let query  = 'SELECT id,name,email,role,avatar,badge,points,is_active,created_at FROM users WHERE 1=1';
  const params = [];
  if (role)   { query += ' AND role=?';           params.push(role); }
  if (search) { query += ' AND (name LIKE ? OR email LIKE ?)'; params.push(`%${search}%`,`%${search}%`); }
  if (req.user.role !== 'admin') { query += ' AND is_active=1'; }
  query += ' ORDER BY name ASC';
  res.json(db.prepare(query).all(...params));
});

// GET /api/users/:id
router.get('/:id', verifyToken, (req, res) => {
  const user = db.prepare('SELECT id,name,email,role,avatar,badge,points,is_active,created_at FROM users WHERE id=?').get(req.params.id);
  if (!user) return res.status(404).json({ message: 'Not found' });
  res.json(user);
});

// GET /api/users/:id/performance
router.get('/:id/performance', verifyToken, (req, res) => {
  const logs = db.prepare('SELECT * FROM performance_log WHERE user_id=? ORDER BY logged_at DESC LIMIT 30').all(req.params.id);
  const submissions = db.prepare(`
    SELECT s.*, t.title as task_title FROM submissions s
    JOIN tasks t ON t.id = s.task_id
    WHERE s.submitted_by=? ORDER BY s.submitted_at DESC LIMIT 10
  `).all(req.params.id);
  const stats = db.prepare(`
    SELECT
      COUNT(*) as total,
      AVG(nexus_score) as avg_score,
      SUM(CASE WHEN leader_status='approved' THEN 1 ELSE 0 END) as approved,
      SUM(CASE WHEN leader_status='rejected' THEN 1 ELSE 0 END) as rejected
    FROM submissions WHERE submitted_by=?
  `).get(req.params.id);
  res.json({ logs, submissions, stats });
});

// POST /api/users
router.post('/', verifyToken, checkRole('admin'), async (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password || !role) return res.status(400).json({ message: 'All fields required' });
  try {
    const hash = await hashPassword(password);
    const result = db.prepare('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)').run(name,email.toLowerCase().trim(),hash,role);
    res.json({ message: 'User created', id: result.lastInsertRowid });
  } catch(e) {
    if (e.message.includes('UNIQUE')) return res.status(409).json({ message: 'Email already exists' });
    res.status(500).json({ message: 'Server error' });
  }
});

// PUT /api/users/:id
router.put('/:id', verifyToken, checkRole('admin'), (req, res) => {
  const { name, role, is_active, badge, points } = req.body;
  db.prepare('UPDATE users SET name=COALESCE(?,name), role=COALESCE(?,role), is_active=COALESCE(?,is_active), badge=COALESCE(?,badge), points=COALESCE(?,points) WHERE id=?')
    .run(name, role, is_active, badge, points, req.params.id);
  res.json({ message: 'User updated' });
});

// DELETE /api/users/:id
router.delete('/:id', verifyToken, checkRole('admin'), (req, res) => {
  if (parseInt(req.params.id) === req.user.id) return res.status(400).json({ message: 'Cannot deactivate yourself' });
  db.prepare('UPDATE users SET is_active=0 WHERE id=?').run(req.params.id);
  res.json({ message: 'User deactivated' });
});

module.exports = router;
