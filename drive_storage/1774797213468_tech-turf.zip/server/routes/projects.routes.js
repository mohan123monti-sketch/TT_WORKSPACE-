const router = require('express').Router();
const db     = require('../db');
const { verifyToken, checkRole } = require('../auth');

// GET /api/projects
router.get('/', verifyToken, (req, res) => {
  const { status } = req.query;
  let query = `
    SELECT p.*, u.name as leader_name, c.name as client_name,
      (SELECT COUNT(*) FROM tasks WHERE project_id=p.id) as task_count,
      (SELECT COUNT(*) FROM tasks WHERE project_id=p.id AND status='approved') as completed_tasks
    FROM projects p
    LEFT JOIN users u ON u.id = p.team_leader_id
    LEFT JOIN clients c ON c.id = p.client_id
    WHERE 1=1
  `;
  const params = [];
  if (req.user.role === 'team_leader') {
    query += ' AND p.team_leader_id=?'; params.push(req.user.id);
  } else if (!['admin'].includes(req.user.role)) {
    query += ' AND p.id IN (SELECT DISTINCT project_id FROM tasks WHERE assigned_to=?)';
    params.push(req.user.id);
  }
  if (status) { query += ' AND p.status=?'; params.push(status); }
  query += ' ORDER BY p.created_at DESC';
  res.json(db.prepare(query).all(...params));
});

// GET /api/projects/:id
router.get('/:id', verifyToken, (req, res) => {
  const p = db.prepare(`
    SELECT p.*, u.name as leader_name, c.name as client_name
    FROM projects p
    LEFT JOIN users u ON u.id=p.team_leader_id
    LEFT JOIN clients c ON c.id=p.client_id
    WHERE p.id=?
  `).get(req.params.id);
  if (!p) return res.status(404).json({ message: 'Not found' });
  res.json(p);
});

// GET /api/projects/:id/tasks
router.get('/:id/tasks', verifyToken, (req, res) => {
  const tasks = db.prepare(`
    SELECT t.*, u.name as assignee_name
    FROM tasks t LEFT JOIN users u ON u.id=t.assigned_to
    WHERE t.project_id=? ORDER BY t.created_at ASC
  `).all(req.params.id);
  res.json(tasks);
});

// POST /api/projects
router.post('/', verifyToken, checkRole('admin'), (req, res) => {
  const { title, description, priority, deadline, team_leader_id, client_id } = req.body;
  if (!title) return res.status(400).json({ message: 'Title required' });
  const result = db.prepare(
    'INSERT INTO projects(title,description,priority,deadline,team_leader_id,client_id,created_by) VALUES(?,?,?,?,?,?,?)'
  ).run(title,description,priority||'normal',deadline,team_leader_id||null,client_id||null,req.user.id);

  if (team_leader_id) {
    db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
      .run(team_leader_id, `📋 You've been assigned as Team Leader for project: "${title}"`, 'info');
  }
  res.json({ message: 'Project created', id: result.lastInsertRowid });
});

// PUT /api/projects/:id
router.put('/:id', verifyToken, checkRole('admin','team_leader'), (req, res) => {
  const { title, description, status, priority, deadline, team_leader_id, client_id } = req.body;
  db.prepare(`UPDATE projects SET
    title=COALESCE(?,title), description=COALESCE(?,description),
    status=COALESCE(?,status), priority=COALESCE(?,priority),
    deadline=COALESCE(?,deadline), team_leader_id=COALESCE(?,team_leader_id),
    client_id=COALESCE(?,client_id) WHERE id=?
  `).run(title,description,status,priority,deadline,team_leader_id,client_id,req.params.id);
  res.json({ message: 'Project updated' });
});

// DELETE /api/projects/:id
router.delete('/:id', verifyToken, checkRole('admin'), (req, res) => {
  db.prepare('UPDATE projects SET status=? WHERE id=?').run('archived', req.params.id);
  res.json({ message: 'Project archived' });
});

module.exports = router;
