const router = require('express').Router();
const db     = require('../db');
const { verifyToken, checkRole } = require('../auth');

router.get('/', verifyToken, (req, res) => {
  const clients = db.prepare(`
    SELECT c.*, (SELECT COUNT(*) FROM projects WHERE client_id=c.id AND status='active') as active_projects
    FROM clients c ORDER BY c.name ASC
  `).all();
  res.json(clients);
});

router.get('/:id', verifyToken, (req, res) => {
  const c = db.prepare('SELECT * FROM clients WHERE id=?').get(req.params.id);
  if (!c) return res.status(404).json({ message: 'Not found' });
  const projects = db.prepare('SELECT * FROM projects WHERE client_id=? ORDER BY created_at DESC').all(req.params.id);
  res.json({ ...c, projects });
});

router.post('/', verifyToken, checkRole('admin','client_handler'), (req, res) => {
  const { name, company, email, phone, brand_colors, brand_tone, audience, goals } = req.body;
  if (!name) return res.status(400).json({ message: 'Name required' });
  const result = db.prepare('INSERT INTO clients(name,company,email,phone,brand_colors,brand_tone,audience,goals) VALUES(?,?,?,?,?,?,?,?)')
    .run(name,company,email,phone,brand_colors,brand_tone,audience,goals);
  res.json({ message: 'Client created', id: result.lastInsertRowid });
});

router.put('/:id', verifyToken, checkRole('admin','client_handler'), (req, res) => {
  const { name, company, email, phone, brand_colors, brand_tone, audience, goals, retainer_mode } = req.body;
  db.prepare('UPDATE clients SET name=COALESCE(?,name), company=COALESCE(?,company), email=COALESCE(?,email), phone=COALESCE(?,phone), brand_colors=COALESCE(?,brand_colors), brand_tone=COALESCE(?,brand_tone), audience=COALESCE(?,audience), goals=COALESCE(?,goals), retainer_mode=COALESCE(?,retainer_mode) WHERE id=?')
    .run(name,company,email,phone,brand_colors,brand_tone,audience,goals,retainer_mode,req.params.id);
  res.json({ message: 'Client updated' });
});

router.post('/:id/feedback', verifyToken, (req, res) => {
  const { score } = req.body; // 1-5
  if (!score || score < 1 || score > 5) return res.status(400).json({ message: 'Score must be 1-5' });
  db.prepare('UPDATE clients SET satisfaction_score=? WHERE id=?').run(score, req.params.id);
  res.json({ message: 'Feedback recorded' });
});

module.exports = router;
