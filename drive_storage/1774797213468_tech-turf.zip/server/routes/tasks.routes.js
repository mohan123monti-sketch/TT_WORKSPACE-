const router = require('express').Router();
const db     = require('../db');
const { verifyToken, checkRole } = require('../auth');

// GET /api/tasks
router.get('/', verifyToken, (req, res) => {
  const { project_id, status, assigned_to } = req.query;
  let query = `
    SELECT t.*, u.name as assignee_name, p.title as project_title
    FROM tasks t
    LEFT JOIN users u ON u.id=t.assigned_to
    LEFT JOIN projects p ON p.id=t.project_id
    WHERE 1=1
  `;
  const params = [];
  if (!['admin','team_leader'].includes(req.user.role)) {
    query += ' AND t.assigned_to=?'; params.push(req.user.id);
  }
  if (project_id) { query += ' AND t.project_id=?';  params.push(project_id); }
  if (status)     { query += ' AND t.status=?';       params.push(status); }
  if (assigned_to){ query += ' AND t.assigned_to=?';  params.push(assigned_to); }
  query += ' ORDER BY CASE t.priority WHEN "urgent" THEN 1 WHEN "normal" THEN 2 ELSE 3 END, t.deadline ASC';
  res.json(db.prepare(query).all(...params));
});

// GET /api/tasks/:id
router.get('/:id', verifyToken, (req, res) => {
  const task = db.prepare(`
    SELECT t.*, u.name as assignee_name, p.title as project_title
    FROM tasks t
    LEFT JOIN users u ON u.id=t.assigned_to
    LEFT JOIN projects p ON p.id=t.project_id
    WHERE t.id=?
  `).get(req.params.id);
  if (!task) return res.status(404).json({ message: 'Not found' });
  res.json(task);
});

// POST /api/tasks
router.post('/', verifyToken, checkRole('admin','team_leader'), (req, res) => {
  const { project_id, title, description, assigned_to, role_required, priority, deadline, depends_on, max_revisions } = req.body;
  if (!project_id || !title) return res.status(400).json({ message: 'project_id and title required' });
  const result = db.prepare(`
    INSERT INTO tasks(project_id,title,description,assigned_to,role_required,priority,deadline,depends_on,max_revisions,created_by)
    VALUES(?,?,?,?,?,?,?,?,?,?)
  `).run(project_id,title,description,assigned_to||null,role_required,priority||'normal',deadline,depends_on||null,max_revisions||3,req.user.id);

  if (assigned_to) {
    db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
      .run(assigned_to, `📌 New task assigned to you: "${title}"`, 'info');
  }
  res.json({ message: 'Task created', id: result.lastInsertRowid });
});

// PUT /api/tasks/:id
router.put('/:id', verifyToken, checkRole('admin','team_leader'), (req, res) => {
  const { title, description, assigned_to, status, priority, deadline, max_revisions } = req.body;
  db.prepare(`UPDATE tasks SET
    title=COALESCE(?,title), description=COALESCE(?,description),
    assigned_to=COALESCE(?,assigned_to), status=COALESCE(?,status),
    priority=COALESCE(?,priority), deadline=COALESCE(?,deadline),
    max_revisions=COALESCE(?,max_revisions) WHERE id=?
  `).run(title,description,assigned_to,status,priority,deadline,max_revisions,req.params.id);
  res.json({ message: 'Task updated' });
});

// POST /api/tasks/:id/rework
router.post('/:id/rework', verifyToken, checkRole('admin','team_leader'), (req, res) => {
  const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!task) return res.status(404).json({ message: 'Not found' });
  if (task.revision_count >= task.max_revisions) {
    return res.status(400).json({ message: `Max revisions (${task.max_revisions}) reached. Escalate to Admin.` });
  }
  db.prepare("UPDATE tasks SET status='rework', revision_count=revision_count+1 WHERE id=?").run(task.id);
  db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
    .run(task.assigned_to, `🔄 Task "${task.title}" sent back for rework (${task.revision_count+1}/${task.max_revisions})`, 'warning');

  if (task.revision_count + 1 >= task.max_revisions) {
    const admin = db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get();
    if (admin) db.prepare("INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)")
      .run(admin.id, `⚠️ FINAL revision for task "${task.title}" — review urgently`, 'danger');
  }
  res.json({ message: 'Sent for rework' });
});

// PUT /api/tasks/:id/start
router.put('/:id/start', verifyToken, (req, res) => {
  const task = db.prepare('SELECT * FROM tasks WHERE id=? AND assigned_to=?').get(req.params.id, req.user.id);
  if (!task) return res.status(404).json({ message: 'Not found or not assigned to you' });
  db.prepare("UPDATE tasks SET status='in_progress' WHERE id=?").run(task.id);
  res.json({ message: 'Task started' });
});

module.exports = router;
