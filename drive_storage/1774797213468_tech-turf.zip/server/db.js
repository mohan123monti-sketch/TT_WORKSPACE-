const Database = require('better-sqlite3');
const path = require('path');
require('dotenv').config();

const dbPath = process.env.DB_PATH || path.join(__dirname, '../techturf.db');
const db = new Database(dbPath);

db.exec(`
-- USERS
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN (
    'admin','team_leader','rnd','writer',
    'designer','media_manager','creator','client_handler'
  )),
  avatar TEXT,
  badge TEXT DEFAULT NULL,
  points INTEGER DEFAULT 0,
  is_active INTEGER DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- CLIENTS
CREATE TABLE IF NOT EXISTS clients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  company TEXT,
  email TEXT,
  phone TEXT,
  brand_colors TEXT,
  brand_tone TEXT,
  audience TEXT,
  goals TEXT,
  portal_password TEXT,
  satisfaction_score REAL DEFAULT 0,
  retainer_mode INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- PROJECTS
CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT DEFAULT 'active' CHECK(status IN ('active','paused','completed','archived')),
  priority TEXT DEFAULT 'normal' CHECK(priority IN ('urgent','normal','low')),
  team_leader_id INTEGER REFERENCES users(id),
  client_id INTEGER REFERENCES clients(id),
  deadline DATE,
  created_by INTEGER REFERENCES users(id),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- TASKS
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER REFERENCES projects(id),
  title TEXT NOT NULL,
  description TEXT,
  assigned_to INTEGER REFERENCES users(id),
  role_required TEXT,
  status TEXT DEFAULT 'pending' CHECK(status IN (
    'pending','in_progress','submitted','approved','rejected','rework'
  )),
  priority TEXT DEFAULT 'normal' CHECK(priority IN ('urgent','normal','low')),
  depends_on INTEGER REFERENCES tasks(id),
  deadline DATE,
  revision_count INTEGER DEFAULT 0,
  max_revisions INTEGER DEFAULT 3,
  created_by INTEGER REFERENCES users(id),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- SUBMISSIONS
CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER REFERENCES tasks(id),
  submitted_by INTEGER REFERENCES users(id),
  file_path TEXT,
  content_text TEXT,
  version INTEGER DEFAULT 1,
  nexus_score INTEGER,
  nexus_feedback TEXT,
  nexus_status TEXT CHECK(nexus_status IN ('approved','improve','rejected')),
  leader_status TEXT DEFAULT 'pending' CHECK(leader_status IN ('approved','rejected','rework','pending')),
  admin_override TEXT,
  submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ANNOUNCEMENTS
CREATE TABLE IF NOT EXISTS announcements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  created_by INTEGER REFERENCES users(id),
  pinned INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- PERFORMANCE LOG
CREATE TABLE IF NOT EXISTS performance_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id),
  action TEXT NOT NULL,
  score INTEGER DEFAULT 0,
  project_id INTEGER,
  task_id INTEGER,
  logged_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- NOTIFICATIONS
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id),
  message TEXT NOT NULL,
  type TEXT DEFAULT 'info' CHECK(type IN ('info','warning','success','danger')),
  is_read INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
`);

module.exports = db;
