async function initUsers() {
  loadUsers();

  document.getElementById('add-user-form').onsubmit = async (e) => {
    e.preventDefault();
    const data = {
      name: document.getElementById('user-name').value,
      email: document.getElementById('user-email').value,
      password: document.getElementById('user-password').value,
      role: document.getElementById('user-role').value
    };
    try {
      await api.post('/users', data);
      showToast('User created successfully', 'success');
      closeModal('add-user-modal');
      loadUsers();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };
}

async function loadUsers() {
  try {
    const users = await api.get('/users');
    const tbody = document.getElementById('users-list-body');
    tbody.innerHTML = users.map(u => `
      <tr onclick="openUserPerformance(${u.id})" style="cursor:pointer;">
        <td>
          <div class="user-cell">
            <img src="${getInitialsAvatar(u.name, 36)}" class="user-avatar-img" style="border:2px solid ${getRoleColor(u.role)}">
            <div>
              <div class="user-name-text">${u.name}</div>
              <div class="user-email-text">${u.email}</div>
            </div>
          </div>
        </td>
        <td><div class="badge" style="background:rgba(255,255,255,0.05); color:${getRoleColor(u.role)}; border:1px solid ${getRoleColor(u.role)}22;">${formatRole(u.role)}</div></td>
        <td><div class="points-cell">${u.points}</div></td>
        <td>${u.badge ? `<div class="badge badge-approved" style="font-size:0.6rem;">${u.badge}</div>` : '—'}</td>
        <td><div class="badge badge-${u.is_active ? 'approved' : 'rejected'}">${u.is_active ? 'Active' : 'Inactive'}</div></td>
        <td>
          <div style="display:flex; gap:12px;">
            <i class="fas fa-edit" style="color:var(--text-muted); cursor:pointer;" onclick="event.stopPropagation(); editUser(${u.id})"></i>
            <i class="fas fa-trash-alt" style="color:var(--accent-secondary); cursor:pointer;" onclick="event.stopPropagation(); deactivateUser(${u.id})"></i>
          </div>
        </td>
      </tr>
    `).join('');
  } catch (e) {
    showToast('Failed to load users', 'error');
  }
}

async function openUserPerformance(id) {
  try {
    const perf = await api.get(`/users/${id}/performance`);
    const user = await api.get(`/users/${id}`);
    const panel = document.getElementById('detail-panel');
    const overlay = document.getElementById('detail-panel-overlay');
    
    document.getElementById('panel-title').textContent = user.name;
    document.getElementById('panel-body').innerHTML = `
      <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:12px; margin-bottom:32px;">
        <div class="glass-card" style="padding:12px; text-align:center;">
          <div style="font-size:0.6rem; color:var(--text-muted); margin-bottom:4px;">AVG SCORE</div>
          <div style="font-family:var(--font-mono); font-weight:700; color:var(--accent-pink);">${Math.round(perf.stats.avg_score || 0)}</div>
        </div>
        <div class="glass-card" style="padding:12px; text-align:center;">
          <div style="font-size:0.6rem; color:var(--text-muted); margin-bottom:4px;">APPROVED</div>
          <div style="font-family:var(--font-mono); font-weight:700; color:var(--accent-green);">${perf.stats.approved || 0}</div>
        </div>
        <div class="glass-card" style="padding:12px; text-align:center;">
          <div style="font-size:0.6rem; color:var(--text-muted); margin-bottom:4px;">REJECTED</div>
          <div style="font-family:var(--font-mono); font-weight:700; color:var(--accent-secondary);">${perf.stats.rejected || 0}</div>
        </div>
      </div>

      <div style="font-family:var(--font-display); font-size:0.9rem; margin-bottom:16px;">RECENT SUBMISSIONS</div>
      <div style="display:flex; flex-direction:column; gap:10px; margin-bottom:32px;">
        ${perf.submissions.length === 0 ? '<div style="color:var(--text-muted); font-size:0.8rem;">No submissions yet.</div>' : perf.submissions.map(s => `
          <div style="padding:12px; background:var(--bg-hover); border-radius:var(--radius-sm); display:flex; justify-content:space-between; align-items:center;">
            <div>
              <div style="font-weight:700; font-size:0.85rem;">${s.task_title}</div>
              <div style="font-size:0.65rem; color:var(--text-muted);">Score: ${s.nexus_score || '—'} • ${timeAgo(s.submitted_at)}</div>
            </div>
            <div class="badge badge-${s.leader_status}">${s.leader_status}</div>
          </div>
        `).join('')}
      </div>

      <div style="font-family:var(--font-display); font-size:0.9rem; margin-bottom:16px;">PERFORMANCE LOG</div>
      <div style="display:flex; flex-direction:column; gap:8px;">
        ${perf.logs.length === 0 ? '<div style="color:var(--text-muted); font-size:0.8rem;">No activity logged.</div>' : perf.logs.map(l => `
          <div style="font-size:0.75rem; display:flex; justify-content:space-between; color:var(--text-secondary);">
            <span>${l.action} ${l.score ? `<span style="color:var(--accent-green);">+${l.score}</span>` : ''}</span>
            <span style="color:var(--text-muted);">${timeAgo(l.logged_at)}</span>
          </div>
        `).join('')}
      </div>
    `;
    
    panel.classList.add('open');
    overlay.style.display = 'block';
    overlay.onclick = closeDetailPanel;
  } catch (e) {
    showToast('Failed to load performance data', 'error');
  }
}

function closeDetailPanel() {
  document.getElementById('detail-panel').classList.remove('open');
  document.getElementById('detail-panel-overlay').style.display = 'none';
}

async function deactivateUser(id) {
  if (!confirm('Are you sure you want to deactivate this user?')) return;
  try {
    await api.delete(`/users/${id}`);
    showToast('User deactivated', 'success');
    loadUsers();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

window.initUsers = initUsers;
window.openUserPerformance = openUserPerformance;
window.closeDetailPanel = closeDetailPanel;
window.deactivateUser = deactivateUser;
