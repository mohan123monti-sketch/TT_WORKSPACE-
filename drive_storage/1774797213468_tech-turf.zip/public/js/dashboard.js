async function initDashboard() {
  try {
    loadMyTasks();
    loadProjectProgress();
    loadNexusLatest();
    loadAnnouncements();
    if (['admin','team_leader'].includes(auth.getUser().role)) {
      loadTopPerformers();
    }
  } catch (e) {
    console.error('Dashboard init error:', e);
  }
}

async function loadMyTasks() {
  const container = document.getElementById('dash-tasks-list');
  try {
    const tasks = await api.get('/tasks?status=pending,in_progress');
    if (tasks.length === 0) {
      container.innerHTML = '<div style="color:var(--text-muted); font-size:0.8rem; text-align:center; padding:20px;">No active tasks</div>';
      return;
    }
    container.innerHTML = tasks.slice(0, 4).map(t => `
      <div style="padding:12px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">
        <div>
          <div style="font-weight:700; font-size:0.9rem;">${t.title}</div>
          <div style="font-size:0.7rem; color:var(--text-muted);">${t.project_title}</div>
        </div>
        <div class="badge badge-${t.priority}">${t.priority}</div>
      </div>
    `).join('');
  } catch (e) {
    container.innerHTML = 'Error loading tasks';
  }
}

async function loadProjectProgress() {
  const container = document.getElementById('dash-projects-list');
  try {
    const projects = await api.get('/projects?status=active');
    if (projects.length === 0) {
      container.innerHTML = '<div style="color:var(--text-muted); font-size:0.8rem; text-align:center; padding:20px;">No active projects</div>';
      return;
    }
    container.innerHTML = projects.slice(0, 3).map(p => {
      const pct = p.task_count > 0 ? Math.round((p.completed_tasks / p.task_count) * 100) : 0;
      const color = pct > 80 ? 'var(--accent-green)' : pct > 50 ? 'var(--accent-orange)' : 'var(--accent-secondary)';
      return `
        <div style="margin-bottom:16px;">
          <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:6px;">
            <span style="font-weight:700;">${p.title}</span>
            <span style="color:${color}">${pct}%</span>
          </div>
          <div style="height:6px; background:var(--bg-secondary); border-radius:3px; overflow:hidden;">
            <div style="height:100%; width:${pct}%; background:${color}; transition:0.5s;"></div>
          </div>
        </div>
      `;
    }).join('');
  } catch (e) {
    container.innerHTML = 'Error loading projects';
  }
}

async function loadNexusLatest() {
  const container = document.getElementById('dash-nexus-list');
  try {
    const subs = await api.get('/submissions');
    if (subs.length === 0) {
      container.innerHTML = '<div style="color:var(--text-muted); font-size:0.8rem; text-align:center; padding:20px;">No submissions yet</div>';
      return;
    }
    container.innerHTML = '';
    subs.slice(0, 2).forEach(s => {
      const wrap = document.createElement('div');
      wrap.style.marginBottom = '16px';
      wrap.style.padding = '12px';
      wrap.style.background = 'var(--bg-hover)';
      wrap.style.borderRadius = 'var(--radius-sm)';
      
      const title = document.createElement('div');
      title.style.fontSize = '0.8rem';
      title.style.fontWeight = '700';
      title.style.marginBottom = '10px';
      title.textContent = s.task_title;
      wrap.appendChild(title);
      
      const ringContainer = document.createElement('div');
      wrap.appendChild(ringContainer);
      container.appendChild(wrap);
      
      if (s.nexus_score !== null) {
        createScoreRing(s.nexus_score, ringContainer);
      } else {
        ringContainer.innerHTML = '<div style="font-size:0.7rem; color:var(--text-muted);">Evaluation pending...</div>';
      }
    });
  } catch (e) {
    container.innerHTML = 'Error loading scores';
  }
}

async function loadAnnouncements() {
  const container = document.getElementById('dash-announcements-list');
  try {
    const items = await api.get('/announcements');
    if (items.length === 0) {
      container.innerHTML = '<div style="color:var(--text-muted); font-size:0.8rem; text-align:center; padding:20px;">No announcements</div>';
      return;
    }
    container.innerHTML = items.slice(0, 3).map(a => `
      <div style="margin-bottom:12px; padding-bottom:12px; border-bottom:1px solid var(--border);">
        <div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">
          ${a.pinned ? '<i class="fas fa-thumbtack" style="color:var(--accent-primary); font-size:0.7rem;"></i>' : ''}
          <span style="font-weight:700; font-size:0.85rem;">${a.title}</span>
        </div>
        <div style="font-size:0.7rem; color:var(--text-muted); display:flex; justify-content:space-between;">
          <span>By ${a.author_name}</span>
          <span>${timeAgo(a.created_at)}</span>
        </div>
      </div>
    `).join('');
  } catch (e) {
    container.innerHTML = 'Error loading announcements';
  }
}

async function loadTopPerformers() {
  const container = document.getElementById('dash-performers-list');
  try {
    const users = await api.get('/users');
    const sorted = users.sort((a, b) => b.points - a.points).slice(0, 4);
    container.innerHTML = sorted.map((u, i) => `
      <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px;">
        <div style="font-family:var(--font-display); font-weight:900; color:var(--text-muted); width:20px;">0${i+1}</div>
        <img src="${getInitialsAvatar(u.name, 32)}" style="width:32px; height:32px; border-radius:50%; border:1px solid ${getRoleColor(u.role)};">
        <div style="flex:1;">
          <div style="font-weight:700; font-size:0.85rem;">${u.name}</div>
          <div style="font-size:0.65rem; color:var(--text-muted);">${formatRole(u.role)}</div>
        </div>
        <div style="font-family:var(--font-mono); font-weight:700; color:var(--accent-primary);">${u.points}</div>
      </div>
    `).join('');
  } catch (e) {
    container.innerHTML = 'Error loading performers';
  }
}

window.initDashboard = initDashboard;
