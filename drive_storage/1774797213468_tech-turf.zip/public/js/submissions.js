async function initSubmissions() {
  loadSubmissions();
}

async function loadSubmissions() {
  const status = document.getElementById('filter-status').value;
  let url = '/submissions';
  if (status) url += `?status=${status}`;

  try {
    const subs = await api.get(url);
    const container = document.getElementById('submissions-list');
    if (subs.length === 0) {
      container.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px; color:var(--text-muted);">No submissions found</div>';
      return;
    }

    container.innerHTML = '';
    subs.forEach(s => {
      const card = document.createElement('div');
      card.className = 'glass-card submission-card anim-fade-up';
      
      let actionsHtml = '';
      if (['admin', 'team_leader'].includes(auth.getUser().role) && s.leader_status === 'pending') {
        actionsHtml = `
          <div class="submission-actions">
            <button class="btn-primary" style="background:var(--accent-green); flex:1;" onclick="reviewSubmission(${s.id}, 'approved')">APPROVE</button>
            <button class="btn-primary" style="background:var(--accent-orange); flex:1;" onclick="reviewSubmission(${s.id}, 'rework')">REWORK</button>
            <button class="btn-primary" style="background:var(--accent-secondary); flex:1;" onclick="reviewSubmission(${s.id}, 'rejected')">REJECT</button>
          </div>
        `;
      }

      const feedback = s.nexus_feedback || {};
      
      card.innerHTML = `
        <div class="submission-header">
          <div>
            <div class="submission-title">${s.task_title}</div>
            <div class="submission-project">${s.project_title} • Version ${s.version}</div>
          </div>
          <div class="badge badge-${s.leader_status}">${s.leader_status}</div>
        </div>

        <div class="submitter-info">
          <img src="${getInitialsAvatar(s.submitter_name, 32)}" style="width:32px; height:32px; border-radius:50%;">
          <div>
            <div style="font-weight:700; font-size:0.85rem;">${s.submitter_name}</div>
            <div style="font-size:0.65rem; color:var(--text-muted);">${formatRole(s.submitter_role)} • ${timeAgo(s.submitted_at)}</div>
          </div>
        </div>

        <div id="ring-${s.id}"></div>

        <div class="feedback-box">
          <div class="feedback-item">
            <span class="feedback-label" style="color:var(--accent-green);">✅ WHAT WORKED</span>
            <div>${feedback.what_worked || 'Evaluation pending...'}</div>
          </div>
          <div class="feedback-item">
            <span class="feedback-label" style="color:var(--accent-orange);">⚠️ IMPROVEMENTS</span>
            <div>${feedback.improvements || '—'}</div>
          </div>
        </div>

        ${s.file_path ? `
          <a href="${s.file_path}" target="_blank" style="font-size:0.75rem; color:var(--accent-primary); display:flex; align-items:center; gap:8px;">
            <i class="fas fa-paperclip"></i> View Attached File
          </a>
        ` : ''}

        ${actionsHtml}
      `;
      
      container.appendChild(card);
      if (s.nexus_score !== null) {
        createScoreRing(s.nexus_score, card.querySelector(`#ring-${s.id}`));
      }
    });
  } catch (e) {
    showToast('Failed to load submissions', 'error');
  }
}

async function reviewSubmission(id, status) {
  const note = prompt(`Enter a note for the ${status} (optional):`);
  try {
    await api.put(`/submissions/${id}/leader-review`, { status, note });
    showToast(`Submission ${status}`, 'success');
    loadSubmissions();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

window.initSubmissions = initSubmissions;
window.loadSubmissions = loadSubmissions;
window.reviewSubmission = reviewSubmission;
