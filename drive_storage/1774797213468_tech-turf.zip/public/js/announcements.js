async function initAnnouncements() {
  loadAnnouncements();

  document.getElementById('new-announcement-form').onsubmit = async (e) => {
    e.preventDefault();
    const data = {
      title: document.getElementById('ann-title').value,
      body: document.getElementById('ann-body').value,
      pinned: document.getElementById('ann-pinned').checked
    };
    try {
      await api.post('/announcements', data);
      showToast('Announcement posted', 'success');
      closeModal('new-announcement-modal');
      loadAnnouncements();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };
}

async function loadAnnouncements() {
  try {
    const items = await api.get('/announcements');
    const container = document.getElementById('announcements-list');
    if (items.length === 0) {
      container.innerHTML = '<div style="text-align:center; padding:40px; color:var(--text-muted);">No announcements yet</div>';
      return;
    }
    container.innerHTML = items.map(a => `
      <div class="glass-card announcement-card anim-fade-up ${a.pinned ? 'pinned' : ''}">
        ${a.pinned ? '<i class="fas fa-thumbtack pin-icon"></i>' : ''}
        <div class="announcement-header">
          <img src="${getInitialsAvatar(a.author_name, 48)}" class="announcement-author-avatar">
          <div>
            <div style="font-weight:700; font-size:1.1rem;">${a.author_name}</div>
            <div style="font-size:0.75rem; color:var(--text-muted);">${timeAgo(a.created_at)}</div>
          </div>
        </div>
        <div class="announcement-title">${a.title}</div>
        <div class="announcement-body">${a.body}</div>
        <div class="announcement-footer">
          <span>Tech Turf Internal Feed</span>
          ${auth.getUser().role === 'admin' ? `
            <div style="display:flex; gap:16px;">
              <span style="cursor:pointer; color:var(--accent-primary);" onclick="togglePin(${a.id})">${a.pinned ? 'Unpin' : 'Pin'}</span>
              <span style="cursor:pointer; color:var(--accent-secondary);" onclick="deleteAnnouncement(${a.id})">Delete</span>
            </div>
          ` : ''}
        </div>
      </div>
    `).join('');
  } catch (e) {
    showToast('Failed to load announcements', 'error');
  }
}

async function togglePin(id) {
  try {
    await api.put(`/announcements/${id}/pin`);
    loadAnnouncements();
  } catch (e) {}
}

async function deleteAnnouncement(id) {
  if (!confirm('Are you sure you want to delete this announcement?')) return;
  try {
    await api.delete(`/announcements/${id}`);
    showToast('Announcement deleted', 'success');
    loadAnnouncements();
  } catch (e) {}
}

window.initAnnouncements = initAnnouncements;
window.togglePin = togglePin;
window.deleteAnnouncement = deleteAnnouncement;
