async function initTasks() {
  loadTasks();
  loadFormOptions();
  initUpload();

  document.getElementById('new-task-form').onsubmit = async (e) => {
    e.preventDefault();
    const data = {
      project_id: document.getElementById('task-project').value,
      title: document.getElementById('task-title').value,
      description: document.getElementById('task-desc').value,
      assigned_to: document.getElementById('task-assignee').value || null,
      priority: document.getElementById('task-priority').value,
      deadline: document.getElementById('task-deadline').value
    };
    try {
      await api.post('/tasks', data);
      showToast('Task created successfully', 'success');
      closeModal('new-task-modal');
      loadTasks();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  document.getElementById('submit-form').onsubmit = async (e) => {
    e.preventDefault();
    const btn = document.getElementById('submit-btn');
    const taskId = document.getElementById('submit-task-id').value;
    const text = document.getElementById('submit-text').value;
    const file = document.getElementById('file-input').files[0];

    if (!text && !file) {
      showToast('Please provide content or a file', 'warning');
      return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';

    const formData = new FormData();
    formData.append('task_id', taskId);
    if (text) formData.append('content_text', text);
    if (file) formData.append('file', file);

    try {
      const sub = await api.upload('/submissions', formData);
      showToast('Work submitted! Nexus AI is evaluating...', 'info');
      
      // Trigger Nexus AI
      const evalResult = await api.post('/nexus/evaluate', {
        submissionId: sub.id,
        roleType: auth.getUser().role,
        contentText: text
      });
      
      showNexusResult(evalResult);
    } catch (err) {
      showToast(err.message, 'error');
      btn.disabled = false;
      btn.innerHTML = 'Submit for Review';
    }
  };
}

async function loadTasks() {
  const project = document.getElementById('filter-project').value;
  const status = document.getElementById('filter-status').value;
  const priority = document.getElementById('filter-priority').value;
  
  let url = '/tasks?';
  if (project) url += `project_id=${project}&`;
  if (status) url += `status=${status}&`;
  if (priority) url += `priority=${priority}&`;

  try {
    const tasks = await api.get(url);
    const tbody = document.getElementById('task-list-body');
    if (tasks.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">No tasks found</td></tr>';
      return;
    }
    tbody.innerHTML = tasks.map(t => `
      <tr>
        <td>
          <div class="task-title-cell">${t.title}</div>
          <div class="task-project-cell">${t.project_title}</div>
        </td>
        <td>
          <div style="display:flex; align-items:center; gap:8px;">
            <img src="${getInitialsAvatar(t.assignee_name || '?', 24)}" style="width:24px; height:24px; border-radius:50%;">
            <span>${t.assignee_name || 'Unassigned'}</span>
          </div>
        </td>
        <td><div class="badge badge-${t.priority}">${t.priority}</div></td>
        <td><div class="badge badge-${t.status}">${t.status}</div></td>
        <td>
          <div style="color:${isOverdue(t.deadline) ? 'var(--accent-secondary)' : 'inherit'}">
            ${formatDate(t.deadline)}
          </div>
        </td>
        <td>
          ${(t.assigned_to === auth.getUser().id && ['pending', 'in_progress', 'rework'].includes(t.status)) ? 
            `<button class="btn-primary" style="padding:6px 12px; font-size:0.7rem;" onclick="openSubmitModal(${t.id}, '${t.title.replace(/'/g, "\\'")}')">SUBMIT</button>` : 
            '—'}
        </td>
      </tr>
    `).join('');
  } catch (e) {
    showToast('Failed to load tasks', 'error');
  }
}

function isOverdue(deadline) {
  if (!deadline) return false;
  return new Date(deadline) < new Date().setHours(0,0,0,0);
}

async function loadFormOptions() {
  try {
    const projects = await api.get('/projects?status=active');
    const users = await api.get('/users?is_active=1');
    
    const filterProj = document.getElementById('filter-project');
    const taskProj = document.getElementById('task-project');
    const taskAssignee = document.getElementById('task-assignee');
    
    const projOptions = projects.map(p => `<option value="${p.id}">${p.title}</option>`).join('');
    filterProj.innerHTML += projOptions;
    taskProj.innerHTML = '<option value="">Select Project</option>' + projOptions;
    
    taskAssignee.innerHTML = '<option value="">Select Assignee</option>' + 
      users.map(u => `<option value="${u.id}">${u.name} (${formatRole(u.role)})</option>`).join('');
  } catch (e) {}
}

function initUpload() {
  const zone = document.getElementById('upload-zone');
  const input = document.getElementById('file-input');
  const preview = document.getElementById('upload-preview');

  zone.onclick = () => input.click();
  zone.ondragover = (e) => { e.preventDefault(); zone.classList.add('drag-over'); };
  zone.ondragleave = () => zone.classList.remove('drag-over');
  zone.ondrop = (e) => {
    e.preventDefault();
    zone.classList.remove('drag-over');
    if (e.dataTransfer.files.length) {
      input.files = e.dataTransfer.files;
      updatePreview();
    }
  };
  input.onchange = updatePreview;

  function updatePreview() {
    if (input.files.length) {
      const file = input.files[0];
      preview.style.display = 'flex';
      preview.innerHTML = `
        <i class="fas fa-file"></i>
        <div style="flex:1; overflow:hidden; text-overflow:ellipsis;">${file.name}</div>
        <div style="font-size:0.7rem; color:var(--text-muted);">${(file.size / 1024 / 1024).toFixed(2)} MB</div>
        <i class="fas fa-times" style="cursor:pointer;" onclick="clearUpload()"></i>
      `;
    } else {
      preview.style.display = 'none';
    }
  }
}

function clearUpload() {
  document.getElementById('file-input').value = '';
  document.getElementById('upload-preview').style.display = 'none';
}

function openSubmitModal(id, title) {
  document.getElementById('submit-task-id').value = id;
  document.getElementById('submit-task-info').innerHTML = `
    <div style="font-size:0.7rem; color:var(--text-muted); text-transform:uppercase; margin-bottom:4px;">Submitting for:</div>
    <div style="font-weight:700;">${title}</div>
  `;
  document.getElementById('submit-form').style.display = 'block';
  document.getElementById('nexus-result').style.display = 'none';
  openModal('submit-modal');
}

function showNexusResult(res) {
  document.getElementById('submit-form').style.display = 'none';
  const resultDiv = document.getElementById('nexus-result');
  resultDiv.style.display = 'block';
  
  const ringContainer = document.getElementById('nexus-ring-container');
  createScoreRing(res.score, ringContainer);
  
  const feedback = res.feedback;
  document.getElementById('nexus-feedback').innerHTML = `
    <div style="margin-bottom:12px;"><span style="color:var(--accent-green); font-weight:700;">✅ WHAT WORKED:</span> ${feedback.what_worked}</div>
    <div style="margin-bottom:12px;"><span style="color:var(--accent-orange); font-weight:700;">⚠️ IMPROVEMENTS:</span> ${feedback.improvements}</div>
    <div><span style="color:var(--accent-primary); font-weight:700;">🔧 SUGGESTIONS:</span> ${feedback.suggestions}</div>
  `;
}

window.initTasks = initTasks;
window.loadTasks = loadTasks;
window.openSubmitModal = openSubmitModal;
window.clearUpload = clearUpload;
