async function initClients() {
  loadClients();

  document.getElementById('new-client-form').onsubmit = async (e) => {
    e.preventDefault();
    const data = {
      name: document.getElementById('client-name').value,
      company: document.getElementById('client-company').value,
      email: document.getElementById('client-email').value,
      phone: document.getElementById('client-phone').value,
      brand_tone: document.getElementById('client-tone').value
    };
    try {
      await api.post('/clients', data);
      showToast('Client added successfully', 'success');
      closeModal('new-client-modal');
      loadClients();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };
}

async function loadClients() {
  try {
    const clients = await api.get('/clients');
    const container = document.getElementById('clients-list');
    if (clients.length === 0) {
      container.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px; color:var(--text-muted);">No clients found</div>';
      return;
    }
    container.innerHTML = clients.map(c => `
      <div class="glass-card client-card anim-fade-up" onclick="openClientDetail(${c.id})">
        <div class="client-avatar">${c.name.substring(0, 2).toUpperCase()}</div>
        <div class="client-name">${c.name}</div>
        <div class="client-company">${c.company || 'Private Client'}</div>
        <div class="client-stats">
          <div class="client-stat">
            <div class="client-stat-val">${c.active_projects}</div>
            <div class="client-stat-label">Projects</div>
          </div>
          <div class="client-stat">
            <div class="client-stat-val">${c.satisfaction_score || 0}</div>
            <div class="client-stat-label">Rating</div>
          </div>
        </div>
      </div>
    `).join('');
  } catch (e) {
    showToast('Failed to load clients', 'error');
  }
}

async function openClientDetail(id) {
  try {
    const c = await api.get(`/clients/${id}`);
    const panel = document.getElementById('detail-panel');
    const overlay = document.getElementById('detail-panel-overlay');
    
    document.getElementById('panel-title').textContent = c.name;
    document.getElementById('panel-body').innerHTML = `
      <div style="margin-bottom:24px;">
        <div style="font-size:0.7rem; color:var(--text-muted); text-transform:uppercase; margin-bottom:4px;">Company</div>
        <div style="font-weight:700;">${c.company || '—'}</div>
      </div>
      
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:24px;">
        <div>
          <div style="font-size:0.7rem; color:var(--text-muted); text-transform:uppercase; margin-bottom:4px;">Email</div>
          <div style="font-size:0.85rem;">${c.email || '—'}</div>
        </div>
        <div>
          <div style="font-size:0.7rem; color:var(--text-muted); text-transform:uppercase; margin-bottom:4px;">Phone</div>
          <div style="font-size:0.85rem;">${c.phone || '—'}</div>
        </div>
      </div>

      <div style="margin-bottom:24px; padding:16px; background:var(--bg-hover); border-radius:var(--radius-sm);">
        <div style="font-size:0.7rem; color:var(--text-muted); text-transform:uppercase; margin-bottom:8px;">Brand Strategy</div>
        <div style="margin-bottom:12px;">
          <span style="font-weight:700; font-size:0.75rem; color:var(--accent-primary);">TONE:</span> 
          <span style="font-size:0.85rem;">${c.brand_tone || 'Not defined'}</span>
        </div>
        <div>
          <span style="font-weight:700; font-size:0.75rem; color:var(--accent-primary);">GOALS:</span> 
          <span style="font-size:0.85rem;">${c.goals || 'Not defined'}</span>
        </div>
      </div>

      <div style="font-family:var(--font-display); font-size:0.9rem; margin-bottom:16px;">PROJECT HISTORY</div>
      <div style="display:flex; flex-direction:column; gap:10px;">
        ${c.projects.length === 0 ? '<div style="color:var(--text-muted); font-size:0.8rem;">No projects yet.</div>' : c.projects.map(p => `
          <div style="padding:12px; background:var(--bg-hover); border-radius:var(--radius-sm); display:flex; justify-content:space-between; align-items:center;">
            <div>
              <div style="font-weight:700; font-size:0.85rem;">${p.title}</div>
              <div style="font-size:0.65rem; color:var(--text-muted);">${formatDate(p.created_at)}</div>
            </div>
            <div class="badge badge-${p.status}">${p.status}</div>
          </div>
        `).join('')}
      </div>
    `;
    
    panel.classList.add('open');
    overlay.style.display = 'block';
    overlay.onclick = closeDetailPanel;
  } catch (e) {
    showToast('Failed to load client details', 'error');
  }
}

function closeDetailPanel() {
  document.getElementById('detail-panel').classList.remove('open');
  document.getElementById('detail-panel-overlay').style.display = 'none';
}

window.initClients = initClients;
window.openClientDetail = openClientDetail;
window.closeDetailPanel = closeDetailPanel;
