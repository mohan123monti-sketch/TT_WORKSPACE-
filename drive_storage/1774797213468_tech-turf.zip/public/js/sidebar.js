function initSidebar() {
  const sidebar = document.getElementById('sidebar');
  const collapseBtn = document.getElementById('sidebar-collapse-btn');
  const mobileToggle = document.getElementById('mobile-toggle');
  
  // Restore collapse state
  const isCollapsed = localStorage.getItem('tt_sidebar_collapsed') === 'true';
  if (isCollapsed && sidebar) sidebar.classList.add('collapsed');

  if (collapseBtn && sidebar) {
    collapseBtn.onclick = () => {
      sidebar.classList.toggle('collapsed');
      localStorage.setItem('tt_sidebar_collapsed', sidebar.classList.contains('collapsed'));
    };
  }

  if (mobileToggle && sidebar) {
    mobileToggle.onclick = () => {
      sidebar.classList.toggle('mobile-open');
      if (sidebar.classList.contains('mobile-open')) {
        const overlay = document.createElement('div');
        overlay.className = 'sidebar-overlay';
        overlay.onclick = () => {
          sidebar.classList.remove('mobile-open');
          overlay.remove();
        };
        document.body.appendChild(overlay);
      }
    };
  }

  // Active state
  const path = window.location.pathname;
  document.querySelectorAll('.menu-item').forEach(item => {
    const href = item.getAttribute('onclick')?.match(/'(.*?)'/)?.[1];
    if (href && (path.endsWith(href) || (path === '/' && href === 'dashboard.html'))) {
      item.classList.add('active');
    }
  });

  // Logout
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) logoutBtn.onclick = () => auth.logout();

  // Notifications
  const notifBell = document.getElementById('notification-bell');
  const notifDropdown = document.getElementById('notification-dropdown');
  
  if (notifBell && notifDropdown) {
    notifBell.onclick = (e) => {
      e.stopPropagation();
      notifDropdown.style.display = notifDropdown.style.display === 'block' ? 'none' : 'block';
    };
    document.addEventListener('click', () => notifDropdown.style.display = 'none');
    notifDropdown.onclick = (e) => e.stopPropagation();
  }

  loadNotifications();
  setInterval(loadNotifications, 30000);
}

async function loadNotifications() {
  try {
    const notifs = await api.get('/notifications');
    const unreadCount = notifs.filter(n => !n.is_read).length;
    const badge = document.getElementById('notification-badge');
    if (badge) {
      badge.textContent = unreadCount;
      badge.style.display = unreadCount > 0 ? 'block' : 'none';
    }

    const list = document.getElementById('notification-list');
    if (list) {
      if (notifs.length === 0) {
        list.innerHTML = '<div class="notif-empty">No notifications</div>';
        return;
      }
      list.innerHTML = notifs.map(n => `
        <div class="notif-item ${n.is_read ? '' : 'unread'}" onclick="markNotifRead(${n.id})">
          <div class="notif-icon ${n.type}"><i class="fas fa-info"></i></div>
          <div class="notif-content">
            <div class="notif-msg">${n.message}</div>
            <div class="notif-time">${timeAgo(n.created_at)}</div>
          </div>
        </div>
      `).join('');
    }
  } catch (e) {}
}

async function markNotifRead(id) {
  try {
    await api.put(`/notifications/${id}/read`);
    loadNotifications();
  } catch (e) {}
}

window.initSidebar = initSidebar;
window.markNotifRead = markNotifRead;
