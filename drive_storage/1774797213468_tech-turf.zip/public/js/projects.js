async function initProjects() {
  loadProjects();
  loadFormOptions();

  document.getElementById('new-project-form').onsubmit = async (e) => {
    e.preventDefault();
    const data = {
      title: document.getElementById('proj-title').value,
      description: document.getElementById('proj-desc').value,
      priority: document.getElementById('proj-priority').value,
      deadline: document.getElementById('proj-deadline').value,
      team_leader_id: document.getElementById('proj-leader').value || null,
      client_id: document.getElementById('proj-client').value || null
    };
    try {
      await api.post('/projects', data);
      showToast('Project created successfully', 'success');
      closeModal('new-project-modal');
      loadProjects();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };
}

async function loadProjects() {
  try {
    const projects = await api.get('/projects');
    const lists = {
      active: document.getElementById('list-active'),
      paused: document.getElementById('list-paused'),
      completed: document.getElementById('list-completed')
    };
    const counts = {
      active: document.getElementById('count-active'),
      paused: document.getElementById('count-paused'),
      completed: document.getElementById('count-completed')
    };

    Object.values(lists).forEach(l => l.innerHTML = '');
    const groups = { active: [], paused: [], completed: [] };

    projects.forEach(p => {
      if (groups[p.status]) groups[p.status].push(p);
    });

    Object.keys(groups).forEach(status => {
      counts[status].textContent = groups[status].length;
      if (groups[status].length === 0) {
        lists[status].innerHTML = '<div style="color:var(--text-muted); font-size:0.75rem; text-align:center; padding:20px;">No projects</div>';
        return;
      }
      lists[status].innerHTML = groups[status].map(p => {
        const pct = p.task_count > 0 ? Math.round((p.completed_tasks / p.task_count) * 100) : 0;
        return `
          <div class="glass-card project-card anim-fade-up" onclick="openProjectDetail(${p.id})">
            <div class="badge badge-${p.priority} priority-badge">${p.priority}</div>
            <div class="project-card-title">${p.title}</div>
            <div class="project-meta">
              <div><i class="fas fa-user-tie"></i> ${p.client_name || 'No Client'}</div>
              <div><i class="fas fa-user-shield"></i> ${p.leader_name || 'No Leader'}</div>
              <div><i class="fas fa-calendar-alt"></i> ${formatDate(p.deadline)}</div>
            </div>
            <div class="progress-wrap">
              <div style="display:flex; justify-content:space-between; font-size:0.7rem; margin-bottom:4px;">
                <span>Progress</span>
                <span>${pct}%</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill" style="width: ${pct}%"></div>
              </div>
            </div>
          </div>
        `;
      }).join('');
    });
  } catch (e) {
    showToast('Failed to load projects', 'error');
  }
}

async function loadFormOptions() {
  try {
    const leaders = await api.get('/users?role=team_leader');
    const clients = await api.get('/clients');
    
    const leaderSelect = document.getElementById('proj-leader');
    const clientSelect = document.getElementById('proj-client');
    
    leaderSelect.innerHTML = '<option value="">Select Team Leader</option>' + 
      leaders.map(u => `<option value="${u.id}">${u.name}</option>`).join('');
    
    clientSelect.innerHTML = '<option value="">Select Client</option>' + 
      clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
  } catch (e) {}
}

async function openProjectDetail(id) {
  try {
    const p = await api.get(`/projects/${id}`);
    const tasks = await api.get(`/projects/${id}/tasks`);
    
    const panel = document.getElementById('detail-panel');
    const overlay = document.getElementById('detail-panel-overlay');
    
    document.getElementById('panel-title').textContent = p.title;
    document.getElementById('panel-badges').innerHTML = `
      <div class="badge badge-${p.status}">${p.status}</div>
      <div class="badge badge-${p.priority}">${p.priority}</div>
    `;
    
    document.getElementById('panel-body').innerHTML = `
      <div style="margin-bottom:24px; font-size:0.9rem; color:var(--text-secondary); line-height:1.6;">${p.description || 'No description provided.'}</div>
      
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:32px;">
        <div class="glass-card" style="padding:12px;">
          <div style="font-size:0.65rem; color:var(--text-muted); text-transform:uppercase;">Client</div>
          <div style="font-weight:700;">${p.client_name || '—'}</div>
        </div>
        <div class="glass-card" style="padding:12px;">
          <div style="font-size:0.65rem; color:var(--text-muted); text-transform:uppercase;">Deadline</div>
          <div style="font-weight:700;">${formatDate(p.deadline)}</div>
        </div>
      </div>

      <div style="font-family:var(--font-display); font-size:0.9rem; margin-bottom:16px;">TASK LIST</div>
      <div style="display:flex; flex-direction:column; gap:10px;">
        ${tasks.length === 0 ? '<div style="color:var(--text-muted); font-size:0.8rem;">No tasks created yet.</div>' : tasks.map(t => `
          <div style="padding:12px; background:var(--bg-hover); border-radius:var(--radius-sm); display:flex; justify-content:space-between; align-items:center;">
            <div>
              <div style="font-weight:700; font-size:0.85rem;">${t.title}</div>
              <div style="font-size:0.65rem; color:var(--text-muted);">Assigned to: ${t.assignee_name || 'Unassigned'}</div>
            </div>
            <div class="badge badge-${t.status}">${t.status}</div>
          </div>
        `).join('')}
      </div>
    `;
    
    panel.classList.add('open');
    overlay.style.display = 'block';
    overlay.onclick = closeDetailPanel;
  } catch (e) {
    showToast('Failed to load project details', 'error');
  }
}

function closeDetailPanel() {
  document.getElementById('detail-panel').classList.remove('open');
  document.getElementById('detail-panel-overlay').style.display = 'none';
}

window.initProjects = initProjects;
window.openProjectDetail = openProjectDetail;
window.closeDetailPanel = closeDetailPanel;
