const auth = {
  TOKEN_KEY: 'tt_token',
  USER_KEY:  'tt_user',

  setToken(token) { localStorage.setItem(this.TOKEN_KEY, token); },
  getToken()      { return localStorage.getItem(this.TOKEN_KEY); },
  setUser(user)   { localStorage.setItem(this.USER_KEY, JSON.stringify(user)); },
  getUser()       { try { return JSON.parse(localStorage.getItem(this.USER_KEY)); } catch { return null; } },
  isLoggedIn()    { return !!this.getToken(); },

  logout() {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    window.location.href = '/index.html';
  },

  requireAuth() {
    if (!this.isLoggedIn()) {
      if (window.location.pathname !== '/index.html' && !window.location.pathname.endsWith('index.html')) {
        window.location.href = '/index.html';
      }
    }
  },

  requireRole(...roles) {
    const user = this.getUser();
    if (!user || !roles.includes(user.role)) {
      showToast('You do not have permission to access this.', 'error');
      setTimeout(() => window.location.href = '/dashboard.html', 1500);
    }
  },

  initNavbar() {
    const user = this.getUser();
    if (!user) return;
    const avatar = document.getElementById('nav-avatar');
    const name   = document.getElementById('nav-user-name');
    const role   = document.getElementById('nav-user-role');
    if (avatar) avatar.src = getInitialsAvatar(user.name, 40);
    if (name)   name.textContent = user.name;
    if (role)   role.textContent = formatRole(user.role);

    document.querySelectorAll('.admin-only').forEach(el => {
      el.style.display = user.role === 'admin' ? '' : 'none';
    });
    document.querySelectorAll('.admin-tl-only').forEach(el => {
      el.style.display = ['admin','team_leader'].includes(user.role) ? '' : 'none';
    });
  }
};
window.auth = auth;
